const handlers = require('../../core/handlers');
const Exception = require('../../core/exceptions');
const PaymentService = require('../../services').paymentService;

const {User,Pass, PassTrip, PassPoint, Trip, Point, UserPass,Booking, Sequelize, Price} = require('../../core/db/models');
const payFor = require('../../core/constants').payFor;
const Op = Sequelize.Op;

async function add(req,res,next){
    
    try{
        

        var d = new Date();
        var n = d.getDate();
        var month = d.getMonth()+1;
        var year = d.getFullYear();
        var hours = d.getHours();
        var minutes = d.getMinutes();
        var numberoftrips=req.body.trips;
        var numberofzeros="";
      
        if (numberoftrips.toString().length===1) {
            numberofzeros="000";
        }
        if (numberoftrips.toString().length===2) {
            numberofzeros="00";
        }
        if (numberoftrips.toString().length===3) {
            numberofzeros="0";
        }


        var totalcode="TNFPS_"+ year+ month +n+hours+minutes+"_"+numberofzeros+numberoftrips;
        console.log(totalcode)

        const PassBody={
            code:totalcode,
            name: req.body.name,
            trips: req.body.trips,
            validity: req.body.validity,
            isActive: req.body.isActive,
            description: req.body.description,
            discPerRidePercentage: req.body.discPerRidePercentage,
            isSuspended: req.body.isSuspended,
            isDynamic: req.body.isDynamic,
            isForAllPoint: req.body.isForAllPoint,
            isForAllTrip: req.body.isForAllTrip,
            additionalBenefit: req.body.additionalBenefit
        }
         
        const pass = await Pass.create(PassBody);
        
        if  (!pass) return next(Exception.Pass.NO_PASS_FOUND);

        return res.send(handlers.responseHandler.buildResponse(pass));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}


async function update(req,res,next){

    try{
        
        var pass = await Pass.findOne({where: {id: req.body.passId}});

        if (!pass) return next(Exception.Pass.NO_PASS_FOUND);

        var pass = await pass.update(req.body);

       return res.send(handlers.responseHandler.buildResponse({"msg":"updated successfully"}));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}



async function all(req,res,next){

    try{
        
        var passData = await Pass.findAll();
     
        return res.send(handlers.responseHandler.buildResponse(passData));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}


async function ride(userpassData){

    userpassData.forEach( async function (row) {
          
        var bookingData =  await  Booking.findOne({
            where: { userPassId: row.id  },
          });
          
 
          try {
            row["rideStatus"]=  await bookingData.rideStatus;    
            console.log(row["name"]) 
          } catch (error) {
             row["rideStatus"]= await "no information"
          }
              console.log("ASDGASHJDGJSA",row.rideStatus)
         
    });
    return userpassData;
}

async function allPurchasedPasses(req,res,next){

    try{
        
        var userpassData =  await UserPass.findAll({
            include:[
                        {model: User, as: 'user'},
                        { model: Point, as: "pointStart",paranoid: false, required: false, attributes:['name'] },
                        { model: Point, as: "pointStop",paranoid: false, required: false, attributes:['name'] },
                        

                    ]

        })

        
        return res.send(handlers.responseHandler.buildResponse(userpassData));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}

async function getUserPasses(req,res,next){

    try{
        
        var id = req.decode.id;
        var passData = await UserPass.findAll({where: {userId: id,
                              isActive:1},
                              include: [
                                { model: Point, as: "pointStart",paranoid: false, required: false, attributes:['name'] },
                                { model: Point, as: "pointStop",paranoid: false, required: false, attributes:['name'] }
                              ],
                              order: [
                                        ['isActive','desc'],
                                        ['createdAt', 'desc']
                                     ]},
                                             );
     
        return res.send(handlers.responseHandler.buildResponse(passData));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}

async function getAllUserRelatedPass(req,res,next){

    try{

        var id = req.decode.id;
        var passData = await UserPass.findAll({where: {userId: id,
                                                       isActive: 1,
                                                       pointBegin: { [Op.in] : [req.body.fromId, req.body.toId]},
                                                       pointEnd: { [Op.in] : [req.body.fromId, req.body.toId]}}});

        return res.send(handlers.responseHandler.buildResponse(passData));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}


async function getPass(req,res,next){

    try{
        
        var passData = await Pass.findOne({where:{id: req.params.id}});

        if(!passData) return next(Exception.Pass.NO_PASS_FOUND);

        return res.send(handlers.responseHandler.buildResponse(passData));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}
async function filter(req, res, next){
    
    try{

      
        const passFiter = {
            name: req.body.name ? req.body.name : "",
            trips: req.body.trips ? req.body.trips : "",
            code: req.body.code ? req.body.code : "",
            description: req.body.description ? req.body.description : "",
            validity: req.body.validity ? req.body.validity : "",
            isActive: req.body.isActive ? req.body.isActive : "",
            isSuspended: req.body.isSuspended ? req.body.isSuspended : "",
            discPerRidePercentage: req.body.discPerRidePercentage ? req.body.discPerRidePercentage : "",
            additionalBenefit: req.body.additionalBenefit ? req.body.additionalBenefit : "",
           
        }

        const passData = await Pass.findAll({where:{
            name : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('name')), 'LIKE', '%' + passFiter.name + '%'),
            trips : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('trips')), 'LIKE', '%' + passFiter.trips + '%'),
            validity : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('validity')), 'LIKE', '%' + passFiter.validity + '%'),
            description : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('description')), 'LIKE', '%' + passFiter.description + '%'),
            code : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('code')), 'LIKE', '%' + passFiter.code + '%'),
            isActive : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('isActive')), 'LIKE', '%' + passFiter.isActive + '%'),
            isSuspended : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('isSuspended')), 'LIKE', '%' + passFiter.isSuspended + '%'),
            discPerRidePercentage : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('discPerRidePercentage')), 'LIKE', '%' + passFiter.discPerRidePercentage + '%'),
            additionalBenefit : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('additionalBenefit')), 'LIKE', '%' + passFiter.additionalBenefit + '%'),
           
        }});

        return res.send(handlers.responseHandler.buildResponse(passData));
    }catch (e){
        console.log('error',e);
        next(e)
    }
}


async function filterPurchasedPasses(req, res, next){
    
    try{
       
       
      

        console.log("DJSHADJHSGAHJD",req.body.activateAt)
        const passFiter = {
            validUpto: req.body.validUpto ? req.body.validUpto : "",
            description: req.body.description ? req.body.description : "",
            code: req.body.code ? req.body.code : "",
            orderId: req.body.orderId ? req.body.orderId : "",
            validity: req.body.validity ? req.body.validity : "",
            price: req.body.price ? req.body.price : "",
            tripAllowed: req.body.tripAllowed ? req.body.tripAllowed : "",
            tripConsume: req.body.tripConsume ? req.body.tripConsume : "",
            name: req.body.username ? req.body.username : "",
            email: req.body.email ? req.body.email : "",
            mobile: req.body.mobile ? req.body.mobile : "",
            gender: req.body.gender ? req.body.gender : "",
            pointStart: req.body.pointBegin ? req.body.pointBegin : "",
            pointStop: req.body.pointEnd ? req.body.pointEnd : "",
            orderStatus: req.body.orderStatus ? req.body.orderStatus : "",
            activateAt: req.body.activateAt ? req.body.activateAt : "",
            createdAt: req.body.createdAt ? req.body.createdAt : "",
        }
        console.log("activateAt",passFiter.activateAt)
        const passData = await UserPass.findAll({
            include:[
                {model: User, as: 'user'},
                { model: Point, as: "pointStart",paranoid: false, required: false, attributes:['name'] },
                { model: Point, as: "pointStop",paranoid: false, required: false, attributes:['name'] }
            ],
            where:{
            validUpto : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('validUpto')), 'LIKE', '%' + passFiter.validUpto + '%'),
            description : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('description')), 'LIKE', '%' + passFiter.description + '%'),
            orderId : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('orderId')), 'LIKE', '%' + passFiter.orderId + '%'),
            code : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('code')), 'LIKE', '%' + passFiter.code + '%'),
            validity : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('validity')), 'LIKE', '%' + passFiter.validity + '%'),
            price : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('price')), 'LIKE', '%' + passFiter.price + '%'),
            tripAllowed : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('tripAllowed')), 'LIKE', '%' + passFiter.tripAllowed + '%'),
            tripConsume : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('tripConsume')), 'LIKE', '%' + passFiter.tripConsume + '%'),
             name : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('user.name')), 'LIKE', '%' + passFiter.name + '%'),
           // email : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('email')), 'LIKE', '%' + passFiter.email + '%'),
            mobile : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('mobile')), 'LIKE', '%' + passFiter.mobile + '%'),
            gender : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('gender')), 'LIKE', '%' + passFiter.gender + '%'),
            pointStart : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('pointStart.name')), 'LIKE', '%' + passFiter.pointStart + '%'),
             pointStop : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('pointStop.name')), 'LIKE', '%' + passFiter.pointStop + '%'),
             orderStatus : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('orderStatus')), 'LIKE', '%' + passFiter.orderStatus + '%'),
             activateAt : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('activateAt')), 'LIKE', '%' + passFiter.activateAt + '%'),
             createdAt : Sequelize.where(Sequelize.fn('LOWER', Sequelize.col('UserPass.createdAt')), 'LIKE', '%' + passFiter.createdAt + '%'),
             
        }
        
    })
        
        
        ;

        return res.send(handlers.responseHandler.buildResponse(passData));
    }catch (e){
        console.log('error',e);
        next(e)
    }
}


async function filtered(req,res,next){
    //only user required it

    try{
        var passData = await PassPoint.findAll({where:{
            pointId: [req.body.startingPointId, req.body.endPointId],
        },
        group: 'passId',
        distinct:true,
        attributes: ['passId', [Sequelize.fn('count', 
        Sequelize.col('pointId')), 'pointCount']],
        raw:true
    });
        // if(!passData) return next(Exception.Pass.NO_PASS_FOUND);

        
        var passIds = passData.filter(data =>{
            return data.pointCount >= 2
        }).map(data => {
            return data.passId
        });
        

        passData = await Pass.findAll({
            where: 
            Sequelize.or(
                {
                    isActive: true,
                    isSuspended: false,
                    isForAllPoint:true
                },
                {
                    id: passIds,
                    isActive: true,
                    isSuspended: false,
                }
            ),
            unique: true,
            raw:true
        });


        var price = await calculatePrice(req.body.startingPointId, req.body.endPointId);

        console.log('price', price);

        var passes = [];

        for (let pass of passData){
            if (pass.isDynamic){
                var totalPrice = pass.trips * price;
                pass.price = totalPrice;
                passes.push(pass);
            }else{
                passes.push(pass);
            }
        }
       
        return res.send(handlers.responseHandler.buildResponse(passes));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}


async function calculatePrice(from, to){

    var price  = await Price.findAll({where:{
        fromId: from,
        toId: to,
        date: {
            [Sequelize.Op.lte]: new Date()
        }
    },
    group:['tripId'],
    attributes:[[Sequelize.fn('max', Sequelize.col('price')), 'maxPrice']],
    unique: true,
    raw:true
});

        console.log(price);
        var maxPrice = 0;

        for (let pc of price){
            if (maxPrice <  pc.maxPrice){
                maxPrice = pc.maxPrice;
            }
        }

        return maxPrice;
}



async function addTrip(req,res,next){

    try{
        
        var passId = req.body.passId;

        let objs = req.body.tripIds.map( async tripId =>{
            let trip = {
                tripId: tripId,
                passId: passId
            };

            

            const tripData = await  PassPoint.findOne({where:trip});

            if (!tripData) await PassPoint.create(trip);

            return trip;
        });

        return res.send(handlers.responseHandler.buildResponse({"msg": "added successfully"}));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}

async function getTrip(req,res,next){

    try{

        let tripsData = await PassTrip.findAll({where: {passId: req.params.id},
            include: [{model: Trip, as: 'trip', paranoid: false, required: false, attributes:['name']}]
        });

        return res.send(handlers.responseHandler.buildResponse(tripsData));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}


async function addPoint(req,res,next){

    try{
        
        var passId = req.body.passId;

        let objs = req.body.pointIds.map( async pointId =>{
            let pt = {
                pointId: pointId,
                passId: passId
            };

            const pointData = await  PassPoint.findOne({where:pt});

            if (!pointData) await PassPoint.create(pt);

            return pt;
        });

        return res.send(handlers.responseHandler.buildResponse({"msg": "added successfully"}));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}

async function getPoint(req,res,next){

    try{

        let tripsData = await PassPoint.findAll({where: {passId: req.params.id},
            include: [{model: Point, as: 'point', paranoid: false, required: false, attributes:['name']}]
        });

        return res.send(handlers.responseHandler.buildResponse(tripsData));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}

async function deletePoint(req,res,next){

    try{

        let pointsData = await PassPoint.destroy({where: {id: req.body.passPointIds}});
        
        return res.send(handlers.responseHandler.buildResponse({"msg": "points deleted successsfully"}));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}


async function deleteTrip(req,res,next){

    try{
        var tripData = await PassTrip.destroy({where: {id: req.body.passTripIds}});

        return res.send(handlers.responseHandler.buildResponse({"msg":"trips deleted successfully"}));

    }catch (e){
        console.log('error',e);
        next(e)
    }

}

async function activatePass(req,res,next){
   
    try{
        const uPass = await UserPass.findOne({
            where: {
                orderId: req.body.orderId 
            }
        });

        await uPass.update({
            isActive: 1,
            orderStatus: "completed"
        });

        return res.send(handlers.responseHandler.buildResponse({"msg":"pass activated"}));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}

async function buyPass(req,res,next){

    try{
        //check for pass
        const pass = await Pass.findOne({where:{id: req.body.passId}});

        if(!pass) return next(Exception.Pass.NO_PASS_FOUND);

        //create order 
        var finalPrice = req.body.amount;
       /*iif (pass.isDynamic){    
            finalPrice = await calculatePrice(req.body.from, req.body.to) ;
            finalPrice = finalPrice * pass.trips;
        }else{
        //    finalPrice = pass.price 
        }

       // const percDis = finalPrice * (pass.passPriceDiscPercentage / 100);
       // const discount = Math.min(percDis , pass.maxPassPriceDisc); 
        const discount=pass.discPerRidePercentage;

        finalPrice = finalPrice - ((discount * finalPrice)/100);
        */
        console.log('price', finalPrice);

        const prevPass = await UserPass.findOne({
            where: {
                passId: pass.id 
            },
            attributes:['validUpto'],
            order:[['validUpto', 'desc']]
        });

        var validUpto;
        var activateAt;

        if( prevPass != null && (new Date(prevPass.validUpto) <= new Date())){
            var today = new Date(prevPass.validUpto);
            activateAt = today;
            today.setDate(today.getDate() + pass.validity);
            validUpto = today;
        }else{
            var today = new Date();
            today.setDate(today.getDate() + pass.validity);
            validUpto = today;
            activateAt = new Date();
        }

        var points;

        if(!pass.isForAllPoint){
            const data = await Point.findAll({
                where:{isActive: true},
                attributes:['id'],
                 raw: true});
            points = JSON.stringify(data.map(point => {
                return point.id
            }));
        }else{
            const data = await PassPoint.findAll({
                where: {
                    passId: pass.id
                },
                attributes:['pointId'],
                raw: true
            })

            points = JSON.stringify(data.map(point => {
                return point.pointId
            }));
        }



        var trips;

        if(!pass.isForAllJourney){
            const data = await Trip.findAll({
                where:{isActive: true},
                attributes: ['id'],
                raw:true
            });

            trips = JSON.stringify(data.map(trip =>{
                return trip.id
            }));

        }else{

            const data = await PassTrip.findAll({
                where: {passId: pass.id},
                attributes:['tripId'],
                raw: true
            });

            trips = JSON.stringify(data.map(trip =>{
                return trip.id
            }));
        }
        

    
        var numberofzeros="";
        if (pass.id.toString().length===1) {
            numberofzeros="000";
        }
        if (pass.id.toString().length===2) {
            numberofzeros="00";
        }
        if (pass.id.toString().length===3) {
            numberofzeros="0";
        }


        var totalcode=pass.code+"_"+numberofzeros+pass.id;
        console.log(totalcode)

        const userPassData = {
            name:pass.name,
            validUpto : validUpto,
            tripAllowed: pass.trips,
            validity: pass.validity,
            description:pass.description,
            maxDiscPerRide: pass.maxDiscPerRide,
            maxDiscPerRidePercentage: pass.maxDiscPerRidePercentage,
            isForAllPoint: pass.isForAllPoint,
            isForAllJourney: pass.isForAllJourney,
            activateAt: activateAt,
            points: points,
            trips: trips,
            passId: pass.id,
            userId: req.decode.id,
            price: finalPrice,
            code:totalcode,
            pointBegin: req.body.from,
            pointEnd: req.body.to,
            isActive: 0 
        }

        const userPass = await UserPass.create(userPassData);

        if (!userPass) return next(Exception.Pass.PASS_NOT_CREATED);

        //create payment data
        const orderData = await PaymentService.createOrder({
            amount: finalPrice,
            id: userPass.id,
            payFor: payFor.pass,
        })

        await userPass.update({
            orderId: orderData.id
        })

        return res.send(handlers.responseHandler.buildResponse(orderData));

    }catch (e){
        console.log('error',e);
        next(e)
    }
}





module.exports = {
 
    all,
	allPurchasedPasses,
    add,
    update,
    getPass,
    filtered,
    filter,
    filterPurchasedPasses,
    addTrip,
    getTrip,
    addPoint,
    getPoint,
    deleteTrip,
    deletePoint,
    getAllUserRelatedPass,
    buyPass,
    getUserPasses,
    activatePass
} 

