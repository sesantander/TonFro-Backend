const router = require('express').Router({caseSensitive:true, strict:true});
const controller = require('./passController');
const validation = require('./passValidator');

//get
router.post('/all',validation.getAll, controller.all);

router.post('/allPurchasedPasses', controller.allPurchasedPasses);

router.post('/add', validation.add, controller.add);

router.post('/update',validation.update, controller.update);

router.post('/filter', controller.filter);

router.post('/filterPurchasedPasses', controller.filterPurchasedPasses);

router.post('/filtered', validation.filtered, controller.filtered);

router.post('/trips/add', validation.addTrip, controller.addTrip);

router.post('/trips/delete', validation.deleteTrip, controller.deleteTrip);

router.post('/points/add', validation.addPoint, controller.addPoint);

router.post('/points/delete', validation.deletePoint, controller.deletePoint);

//user related
router.post('/user/all', controller.getAllUserRelatedPass);
router.post('/user/passes', controller.getUserPasses);
router.post('/activate',controller.activatePass);

router.post('/user/buy', validation.buyPass, controller.buyPass);


router.get('/trips/all/:id', controller.getTrip);

router.get('/points/get/:id', controller.getPoint);

router.get ('/:id', controller.getPass);



module.exports = router;   
